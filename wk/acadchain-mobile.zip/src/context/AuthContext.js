// src/context/AuthContext.js
import React, { createContext, useState, useMemo } from 'react';

export const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null); // {name, token}

  const login = async (email, password) => {
    // TODO: integrar com backend Node
    // Por enquanto, login “fake”:
    if (email && password) {
      setUser({ name: 'Usuário Teste', email, token: 'fake-jwt-token' });
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  const value = useMemo(
    () => ({
      user,
      login,
      logout,
    }),
    [user]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
