// src/screens/RegisterDocumentScreen.js
import React, { useContext, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { AuthContext } from '../context/AuthContext';
// import { apiRegisterDocument } from '../services/api'; // quando integrar backend

export default function RegisterDocumentScreen() {
  const { user } = useContext(AuthContext);
  const [title, setTitle] = useState('');
  const [type, setType] = useState('DIPLOMA');
  const [verificationCode, setVerificationCode] = useState(null);

  async function handleRegister() {
    try {
      // Simulação de resposta do backend
      const resp = {
        verificationCode: 'CODIGO-EXEMPLO-123',
        blockchainTxHash: '0x123abc...',
      };

      setVerificationCode(resp.verificationCode);
      Alert.alert('Sucesso', 'Documento registrado com sucesso!');
    } catch (err) {
      Alert.alert('Erro', err.message);
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Título do Documento</Text>
      <TextInput
        style={styles.input}
        placeholder="Ex.: Diploma de Bacharel"
        value={title}
        onChangeText={setTitle}
      />

      <Text style={styles.label}>Tipo</Text>
      <TextInput
        style={styles.input}
        placeholder="DIPLOMA / CERTIFICADO / HISTORICO"
        value={type}
        onChangeText={setType}
      />

      <TouchableOpacity style={styles.button} onPress={handleRegister}>
        <Text style={styles.buttonText}>Registrar Documento</Text>
      </TouchableOpacity>

      {verificationCode && (
        <View style={styles.resultBox}>
          <Text style={styles.resultTitle}>Código de Verificação</Text>
          <Text style={styles.resultCode}>{verificationCode}</Text>
          <Text style={styles.resultHint}>
            Esse código pode ser transformado em QR Code para validação.
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
    backgroundColor: '#F4F6F9',
  },
  label: {
    fontSize: 14,
    marginBottom: 4,
    fontWeight: '500',
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  button: {
    backgroundColor: '#00B894',
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 16,
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
  },
  resultBox: {
    marginTop: 16,
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#dfe6e9',
  },
  resultTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  resultCode: {
    fontSize: 18,
    fontWeight: '700',
    color: '#0984E3',
    marginBottom: 4,
  },
  resultHint: {
    fontSize: 12,
    color: '#636e72',
  },
});
