// src/screens/VerifyDocumentScreen.js
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
// import { apiVerifyDocument } from '../services/api'; // quando integrar backend

export default function VerifyDocumentScreen() {
  const [verificationCode, setVerificationCode] = useState('');
  const [result, setResult] = useState(null);

  async function handleVerify() {
    // Simulação de resposta do backend
    const data = {
      valid: true,
      document: {
        title: 'Diploma de Bacharel em Sistemas de Informação',
        type: 'DIPLOMA',
        issueDate: '2024-01-10',
        blockchainTxHash: '0x123abc...',
      },
    };

    setResult(data);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Código de Verificação</Text>
      <TextInput
        style={styles.input}
        placeholder="Insira o código recebido pelo aluno"
        value={verificationCode}
        onChangeText={setVerificationCode}
      />

      <TouchableOpacity style={styles.button} onPress={handleVerify}>
        <Text style={styles.buttonText}>Validar</Text>
      </TouchableOpacity>

      {result && (
        <View style={styles.resultBox}>
          <Text style={styles.resultTitle}>
            {result.valid ? 'Documento Válido ✅' : 'Documento Inválido ❌'}
          </Text>
          {result.document && (
            <>
              <Text style={styles.resultText}>Título: {result.document.title}</Text>
              <Text style={styles.resultText}>Tipo: {result.document.type}</Text>
              <Text style={styles.resultText}>
                Data de Emissão: {result.document.issueDate}
              </Text>
              <Text style={styles.resultText}>
                Tx Blockchain: {result.document.blockchainTxHash}
              </Text>
            </>
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
    backgroundColor: '#F4F6F9',
  },
  label: {
    fontSize: 14,
    marginBottom: 4,
    fontWeight: '500',
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  button: {
    backgroundColor: '#0984E3',
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 16,
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
  },
  resultBox: {
    marginTop: 16,
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#dfe6e9',
  },
  resultTitle: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 8,
  },
  resultText: {
    fontSize: 13,
    marginBottom: 4,
  },
});
