// src/screens/HomeScreen.js
import React, { useContext } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { AuthContext } from '../context/AuthContext';

export default function HomeScreen({ navigation }) {
  const { user, logout } = useContext(AuthContext);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Bem-vindo, {user?.name}</Text>
      <Text style={styles.subtitle}>
        Escolha uma das opções abaixo:
      </Text>

      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('RegisterDocument')}
      >
        <Text style={styles.buttonText}>Cadastrar Documento</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.buttonSecondary}
        onPress={() => navigation.navigate('VerifyDocument')}
      >
        <Text style={styles.buttonSecondaryText}>Validar Documento</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.logoutButton} onPress={logout}>
        <Text style={styles.logoutText}>Sair</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
    backgroundColor: '#F4F6F9',
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#555',
    marginBottom: 24,
  },
  button: {
    backgroundColor: '#0984E3',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 12,
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
  },
  buttonSecondary: {
    backgroundColor: '#fff',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#0984E3',
  },
  buttonSecondaryText: {
    color: '#0984E3',
    fontWeight: '600',
  },
  logoutButton: {
    marginTop: 'auto',
    alignSelf: 'center',
    padding: 8,
  },
  logoutText: {
    color: '#d63031',
  },
});
