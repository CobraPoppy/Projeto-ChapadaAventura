// src/services/api.js
const API_BASE_URL = 'http://10.0.2.2:3000';

async function handleResponse(response) {
  const text = await response.text();
  let data;
  try {
    data = text ? JSON.parse(text) : {};
  } catch (e) {
    data = { raw: text };
  }

  if (!response.ok) {
    throw new Error(data?.error || 'Erro na requisição');
  }

  return data;
}

export async function apiLogin(email, password) {
  const res = await fetch(`${API_BASE_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  return handleResponse(res);
}

export async function apiRegisterDocument(formData, token) {
  const res = await fetch(`${API_BASE_URL}/documents`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: formData,
  });
  return handleResponse(res);
}

export async function apiVerifyDocument({ verificationCode }) {
  const res = await fetch(`${API_BASE_URL}/documents/code/${verificationCode}`);
  return handleResponse(res);
}
