// src/navigation/AppNavigator.js
import React, { useContext } from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import LoginScreen from '../screens/LoginScreen';
import HomeScreen from '../screens/HomeScreen';
import RegisterDocumentScreen from '../screens/RegisterDocumentScreen';
import VerifyDocumentScreen from '../screens/VerifyDocumentScreen';
import { AuthContext } from '../context/AuthContext';

const Stack = createNativeStackNavigator();

export default function AppNavigator() {
  const { user } = useContext(AuthContext);

  return (
    <Stack.Navigator>
      {user ? (
        <>
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen
            name="RegisterDocument"
            component={RegisterDocumentScreen}
            options={{ title: 'Cadastrar Documento' }}
          />
          <Stack.Screen
            name="VerifyDocument"
            component={VerifyDocumentScreen}
            options={{ title: 'Validar Documento' }}
          />
        </>
      ) : (
        <Stack.Screen
          name="Login"
          component={LoginScreen}
          options={{ headerShown: false }}
        />
      )}
    </Stack.Navigator>
  );
}
