import { apiFetch } from "./api.js";
import { getTrilhas } from "./trails.js";

async function loadBestTrail() {
  const heroCard = document.querySelector(".hero-card");
  if (!heroCard) return;

  try {
    const best = await apiFetch("/api/best-trail", { method: "GET" });

    if (!best) {
      heroCard.innerHTML = `
        <h3>Melhor trilha</h3>
        <p class="muted">Ainda não há avaliações suficientes.</p>
      `;
      return;
    }

    const trilhas = getTrilhas();
    const trail = trilhas.find((t) => t.slug === best.trail_slug);

    if (!trail) {
      heroCard.innerHTML = `
        <h3>Melhor trilha</h3>
        <p class="muted">Não foi possível encontrar detalhes da trilha.</p>
      `;
      return;
    }

    heroCard.innerHTML = `
      <img src="${trail.imagem}" alt="${trail.nome}" class="hero-card-img" />
      <div class="hero-card-content">
        <div class="hero-card-kicker">Melhor avaliada</div>
        <h3>${trail.nome}</h3>
        <p><strong>${Number(best.avg_rating).toFixed(1)}</strong> ★ (${best.total_reviews} avaliação(ões))</p>
        <p>${trail.nivel} • ${trail.dias} • ${trail.partida}</p>
        <a href="trilha.html?slug=${trail.slug}" class="btn btn-primary btn-sm">Ver detalhes da trilha</a>
      </div>
    `;
  } catch (err) {
    console.error("Erro ao carregar trilha melhor avaliada:", err);
  }
}

document.addEventListener("DOMContentLoaded", loadBestTrail);
